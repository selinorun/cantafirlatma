// Matter.js modüllerini yükle
const { Engine, Render, Runner, World, Bodies, Mouse, MouseConstraint, Body } = Matter;

// Fizik motoru oluştur
const engine = Engine.create();
const { world } = engine;

// Yerçekimini aç (Stickerlar fiziksel hareket edebilsin)
engine.world.gravity.y = 1;

// Render ayarları
const render = Render.create({
  element: document.querySelector('#scene'),
  engine: engine,
  options: {
    width: window.innerWidth,
    height: window.innerHeight,
    wireframes: false, // Görsel gerçekçilik için kapat
    background: '#fffbe7', // Masa efekti için arkaplan
  },
});

Render.run(render);
Runner.run(Runner.create(), engine);

// Masa sınırları
World.add(world, [
  // Masa kenarları
  Bodies.rectangle(window.innerWidth / 2, 0, window.innerWidth, 10, { isStatic: true }), // Üst kenar
  Bodies.rectangle(window.innerWidth / 2, window.innerHeight, window.innerWidth, 10, { isStatic: true }), // Alt kenar
  Bodies.rectangle(0, window.innerHeight / 2, 10, window.innerHeight, { isStatic: true }), // Sol kenar
  Bodies.rectangle(window.innerWidth, window.innerHeight / 2, 10, window.innerHeight, { isStatic: true }), // Sağ kenar
]);

// Sticker oluşturma
let stickersCreated = new Set(); // Her görselin sadece bir kez oluşturulması için

document.getElementById('bag').addEventListener('click', () => {
  const totalStickers = 4; // 4 farklı sticker olduğunu belirtiyoruz

  for (let i = 1; i <= totalStickers; i++) {
    if (stickersCreated.has(i)) continue; // Sticker zaten oluşturulmuşsa geç

    const x = Math.random() * (window.innerWidth - 100) + 50; // Rastgele x konumu
    const y = Math.random() * (window.innerHeight - 300) + 100; // Rastgele y konumu (masanın üst bölgesi)

    const sticker = Bodies.rectangle(x, y, 50, 50, { // Sticker fiziksel boyut
      restitution: 0.5, // Hafif zıplama etkisi
      render: {
        sprite: {
          texture: `images/sticker${i}.png`, // Sticker görseli (sticker1.png - sticker4.png)
          xScale: 0.25, // Görsel ölçeklendirme
          yScale: 0.25,
        },
      },
    });

    // Sticker'ı dünyaya ekle
    World.add(world, sticker);
    stickersCreated.add(i); // Stickerı oluşturulanlar listesine ekle
  }
});

// Fare etkileşimi ekle (Sürüklenebilirlik)
const mouse = Mouse.create(render.canvas);
const mouseConstraint = MouseConstraint.create(engine, {
  mouse: mouse,
  constraint: {
    stiffness: 0.2,
    render: { visible: false },
  },
});
World.add(world, mouseConstraint);
